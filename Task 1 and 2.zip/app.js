// arrayManipulation.js

// Function to process the array
function processArray(numbers) {
    return numbers.map(num => num % 2 === 0 ? num * num : num * 3);
}

// Function to format array strings
function formatArrayStrings(strings, processedNumbers) {
    return strings.map((str, index) => {
        const num = processedNumbers[index];
        return num % 2 === 0 ? str.toUpperCase() : str.toLowerCase();
    });
}

// Export the functions for use in other files
module.exports = {
    processArray,
    formatArrayStrings
};
